from django.contrib import admin
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from . import views
from django.urls import path, include
from rest_framework import routers
from core.views import PurchaseViewSet
from .views import login_api

router = routers.DefaultRouter()
router.register(r'purchases', PurchaseViewSet, basename='purchases')

urlpatterns = [

    path('api/login/', login_api, name='login_api'),

    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),    path('logout/', views.logout_view, name='logout'),
    # path('dashboard/', views.dashboard_view, name='dashboard'),

    # پنل مدیر
    path('manager/', views.manager_dashboard, name='manager_dashboard'),
    path('manager/delete_store/<int:store_id>/', views.delete_store, name='delete_store'),
    path('manager/set_budget/<int:school_id>/', views.set_budget, name='set_budget'),
    # path('manager/invoices/', views.invoices_list, name='invoices'),

    # پنل مدرسه
    # path('add_purchase/', views.add_purchase, name='add_purchase'),
]
