from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Budget, Store, School, ManagerSettings
from django.db.models import Sum
from django.contrib import messages
from rest_framework import viewsets, permissions
from .models import Purchase
from .serializers import PurchaseSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate

class PurchaseViewSet(viewsets.ModelViewSet):
    queryset = Purchase.objects.all()
    serializer_class = PurchaseSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'school':
            return Purchase.objects.filter(school=user.school)
        elif user.role == 'manager':
            return Purchase.objects.all()
        return Purchase.objects.none()

@api_view(['POST'])
def login_api(request):
    username = request.data.get('username')
    password = request.data.get('password')
    user = authenticate(request, username=username, password=password)
    if user:
        login(request, user)
        return Response({'success': True})
    else:
        return Response({'error': 'نام کاربری یا رمز عبور اشتباه است'}, status=status.HTTP_401_UNAUTHORIZED)

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')



@login_required
def manage_stores(request):
    if request.method == 'POST':
        data = request.POST
        rows = int(data.get('total_rows', 0))

        for i in range(rows):
            name = data.get(f'store_name_{i}', '')
            if name:
                Store.objects.get_or_create(name=name)

        messages.success(request, "فروشگاه‌ها ذخیره شدند.")
        return redirect('manage_stores')

    stores = Store.objects.all()
    return render(request, 'manage_stores.html', {'stores': stores})

@login_required
def manager_dashboard(request):
    if request.user.role != 'manager':
        return redirect('dashboard')

    stores = Store.objects.all()
    schools = School.objects.all()
    budgets = Budget.objects.all()

    return render(request, 'manager_dashboard.html', {
        'stores': stores,
        'schools': schools,
        'budgets': budgets,
    })


@api_view(['POST'])
def api_add_store(request):
    if request.user.role != 'manager':
        return Response({"detail": "Unauthorized"}, status=status.HTTP_403_FORBIDDEN)

    name = request.data.get('name')
    if name:
        Store.objects.create(name=name)
        return Response({"success": True})
    return Response({"error": "Name is required"}, status=400)

@login_required
def delete_store(request, store_id):
    if request.user.role != 'manager':
        return redirect('dashboard')

    store = get_object_or_404(Store, id=store_id)
    store.delete()
    return redirect('manager_dashboard')

@login_required
def set_budget(request, school_id):
    if request.user.role != 'manager':
        return redirect('dashboard')

    school = get_object_or_404(School, id=school_id)
    if request.method == 'POST':
        budget_type = request.POST.get('budget_type')
        amount = request.POST.get('amount')
        if budget_type and amount:
            Budget.objects.update_or_create(
                school=school,
                budget_type=budget_type,
                defaults={'amount': amount}
            )
            return redirect('manager_dashboard')

    return render(request, 'set_budget.html', {'school': school})

def manager_stores(request):
    stores = Store.objects.all()
    return render(request, 'manager_stores.html', {'stores': stores})

# تنظیمات مالیات مدیر
def manager_settings(request):
    settings, created = ManagerSettings.objects.get_or_create(id=1)

    if request.method == 'POST':
        settings.tax_limit = request.POST.get('tax_limit')
        settings.save()
        messages.success(request, "تنظیمات ذخیره شد!")

    alerts = []
    for store in Store.objects.all():
        total = Purchase.objects.filter(store=store).aggregate(Sum('amount'))['amount__sum'] or 0
        if total > settings.tax_limit:
            alerts.append(f"خرید از {store.name} بیش از حد تعیین شده است ({total})")

    return render(request, 'manager_settings.html', {'settings': settings, 'alerts': alerts})

# فاکتور مدیر
def manager_invoices(request):
    purchases = Purchase.objects.all()
    return render(request, 'manager_invoices.html', {'purchases': purchases})