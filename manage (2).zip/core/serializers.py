from rest_framework import serializers
from .models import Purchase

class PurchaseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Purchase
        fields = ['id', 'school', 'store', 'description', 'quantity', 'price', 'amount', 'created_at']
        read_only_fields = ['id', 'amount', 'created_at']

    def create(self, validated_data):
        validated_data['amount'] = validated_data['quantity'] * validated_data['price']
        return super().create(validated_data)
