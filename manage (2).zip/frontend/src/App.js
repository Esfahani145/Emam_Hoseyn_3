import React from 'react';
import LoginPage from './pages/LoginPage';

const App = () => {
  return (
    <div>
      <LoginPage />
    </div>
  );
};

export default App;
