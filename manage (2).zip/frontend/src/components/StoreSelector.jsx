import React, { useEffect, useState } from 'react';

const StoreSelector = () => {
  const [storeList, setStoreList] = useState([]);
  const [selectedStoreId, setSelectedStoreId] = useState('');

  useEffect(() => {
    fetch("http://localhost:8000/api/stores/")
      .then((res) => res.json())
      .then((data) => {
        console.log("📦 Stores fetched:", data);
        setStoreList(data);
      })
      .catch((err) => {
        console.error("❌ Error fetching stores:", err);
      });
  }, []);

  const handleChange = (e) => {
    const selectedId = e.target.value;
    setSelectedStoreId(selectedId);
    console.log("✅ Store selected:", selectedId);
  };

  return (
    <div>
      <label htmlFor="storeSelect">انتخاب فروشگاه:</label>
      <select
        id="storeSelect"
        value={selectedStoreId}
        onChange={handleChange}
      >
        <option value="">-- انتخاب کنید --</option>
        {storeList.map((store) => (
          <option key={store.id} value={store.id}>
            {store.name}
          </option>
        ))}
      </select>

      {selectedStoreId && (
        <p>🛒 فروشگاه انتخاب‌شده: {storeList.find(s => s.id == selectedStoreId)?.name}</p>
      )}
    </div>
  );
};

export default StoreSelector;
